//package webrix.hr.entity;
//
//import java.util.Date;
//
//import javax.persistence.Entity;
//import javax.persistence.Table;
//
//@Entity
//@Table(name = "dashboard_detail_table")
//public class dashboardEntity {
//	
//	private int candidateCount;
//	private int offerCount;
//	private int processingCount;
//	private int duplicationCount;
//	private int rejectedCount;
//	private int yetToStartCount;
//	private Date lastUpdate;
//	public int getCandidateCount() {
//		return candidateCount;
//	}
//	public void setCandidateCount(int candidateCount) {
//		this.candidateCount = candidateCount;
//	}
//	public int getOfferCount() {
//		return offerCount;
//	}
//	public void setOfferCount(int offerCount) {
//		this.offerCount = offerCount;
//	}
//	public int getProcessingCount() {
//		return processingCount;
//	}
//	public void setProcessingCount(int processingCount) {
//		this.processingCount = processingCount;
//	}
//	public int getDuplicationCount() {
//		return duplicationCount;
//	}
//	public void setDuplicationCount(int duplicationCount) {
//		this.duplicationCount = duplicationCount;
//	}
//	public int getRejectedCount() {
//		return rejectedCount;
//	}
//	public void setRejectedCount(int rejectedCount) {
//		this.rejectedCount = rejectedCount;
//	}
//	public int getYetToStartCount() {
//		return yetToStartCount;
//	}
//	public void setYetToStartCount(int yetToStartCount) {
//		this.yetToStartCount = yetToStartCount;
//	}
//	public Date getLastUpdate() {
//		return lastUpdate;
//	}
//	public void setLastUpdate(Date lastUpdate) {
//		this.lastUpdate = lastUpdate;
//	}
//	
//	
//	
//	
//	
//}
