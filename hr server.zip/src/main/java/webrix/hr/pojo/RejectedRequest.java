package webrix.hr.pojo;

public class RejectedRequest {
	private long rejected_id;
	private String rof;
	private String rejected_msg;
	public long getRejected_id() {
		return rejected_id;
	}
	public void setRejected_id(long rejected_id) {
		this.rejected_id = rejected_id;
	}
	public String getRof() {
		return rof;
	}
	public void setRof(String rof) {
		this.rof = rof;
	}
	public String getRejected_msg() {
		return rejected_msg;
	}
	public void setRejected_msg(String rejected_msg) {
		this.rejected_msg = rejected_msg;
	}
	
	
}
